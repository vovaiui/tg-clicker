-- Создание базы данных
CREATE DATABASE IF NOT EXISTS telegram_wallet CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE telegram_wallet;

-- Таблица пользователей
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    telegram_id BIGINT UNIQUE NOT NULL,
    username VARCHAR(255),
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255),
    language_code VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Таблица категорий
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    type ENUM('income', 'expense') NOT NULL,
    icon VARCHAR(50),
    color VARCHAR(20),
    is_default BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY `user_category` (user_id, name, type)
) ENGINE=InnoDB;

-- Таблица транзакций
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    category_id INT NOT NULL,
    description TEXT,
    transaction_date DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Таблица целей
CREATE TABLE IF NOT EXISTS goals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    target_amount DECIMAL(12, 2) NOT NULL,
    current_amount DECIMAL(12, 2) DEFAULT 0,
    target_date DATE,
    is_completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Вставляем стандартные категории
INSERT INTO categories (user_id, name, type, icon, color, is_default) VALUES
(0, 'Зарплата', 'income', '💼', '#4CAF50', TRUE),
(0, 'Фриланс', 'income', '💻', '#4CAF50', TRUE),
(0, 'Подарки', 'income', '🎁', '#4CAF50', TRUE),
(0, 'Еда', 'expense', '🍔', '#F44336', TRUE),
(0, 'Транспорт', 'expense', '🚕', '#F44336', TRUE),
(0, 'Жилье', 'expense', '🏠', '#F44336', TRUE),
(0, 'Развлечения', 'expense', '🎬', '#F44336', TRUE),
(0, 'Здоровье', 'expense', '🏥', '#F44336', TRUE);