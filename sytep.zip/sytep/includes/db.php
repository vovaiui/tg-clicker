<?php
require_once __DIR__ . '/config.php';

class Database {
    private $connection;

    public function __construct() {
        $this->connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($this->connection->connect_error) {
            die("Connection failed: " . $this->connection->connect_error);
        }
        
        $this->connection->set_charset("utf8mb4");
    }

    public function getConnection() {
        return $this->connection;
    }

    public function query($sql, $params = [], $types = "") {
        $stmt = $this->connection->prepare($sql);
        
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $this->connection->error);
        }
        
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        return $stmt;
    }

    public function fetchAll($sql, $params = [], $types = "") {
        $stmt = $this->query($sql, $params, $types);
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function fetchOne($sql, $params = [], $types = "") {
        $stmt = $this->query($sql, $params, $types);
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    public function insert($table, $data) {
        $columns = implode(", ", array_keys($data));
        $placeholders = implode(", ", array_fill(0, count($data), "?"));
        $values = array_values($data);
        $types = str_repeat("s", count($data));
        
        $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
        $stmt = $this->query($sql, $values, $types);
        
        return $stmt->insert_id;
    }

    public function update($table, $data, $where, $whereParams = [], $whereTypes = "") {
        $setParts = [];
        $values = [];
        $types = "";
        
        foreach ($data as $column => $value) {
            $setParts[] = "$column = ?";
            $values[] = $value;
            $types .= "s";
        }
        
        $sql = "UPDATE $table SET " . implode(", ", $setParts) . " WHERE $where";
        $values = array_merge($values, $whereParams);
        $types .= $whereTypes;
        
        $stmt = $this->query($sql, $values, $types);
        return $stmt->affected_rows;
    }

    public function close() {
        $this->connection->close();
    }
}

// Создаем глобальный экземпляр базы данных
$db = new Database();
?>