<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/config.php';

class Auth {
    private $db;
    private $user = null;

    public function __construct($db) {
        $this->db = $db;
        $this->authenticate();
    }

    private function authenticate() {
        if ($this->validateTelegramData()) {
            $this->user = $this->getOrCreateUser();
            $_SESSION['user_id'] = $this->user['id'];
        } elseif (isset($_SESSION['user_id'])) {
            $this->user = $this->getUserById($_SESSION['user_id']);
        }
    }

    private function validateTelegramData() {
        if (!isset($_POST['initData'])) return false;
        
        $initData = $_POST['initData'];
        parse_str($initData, $parsedData);
        
        if (!isset($parsedData['user'])) return false;
        
        $userData = json_decode($parsedData['user'], true);
        if (!$userData || !isset($userData['id'])) return false;
        
        // В реальном приложении нужно добавить проверку хэша
        // для безопасности
        
        return true;
    }

    private function getOrCreateUser() {
        $initData = $_POST['initData'];
        parse_str($initData, $parsedData);
        $userData = json_decode($parsedData['user'], true);
        
        $telegramId = $userData['id'];
        $user = $this->getUserByTelegramId($telegramId);
        
        if (!$user) {
            $userId = $this->db->insert('users', [
                'telegram_id' => $telegramId,
                'username' => $userData['username'] ?? null,
                'first_name' => $userData['first_name'] ?? 'Unknown',
                'last_name' => $userData['last_name'] ?? null,
                'language_code' => $userData['language_code'] ?? DEFAULT_LANGUAGE
            ]);
            
            $user = $this->getUserById($userId);
            $this->createDefaultCategories($userId);
        }
        
        return $user;
    }

    private function createDefaultCategories($userId) {
        $defaultCategories = $this->db->fetchAll(
            "SELECT name, type, icon, color FROM categories WHERE is_default = TRUE AND (user_id = 0 OR user_id = ?)",
            [$userId],
            "i"
        );
        
        foreach ($defaultCategories as $category) {
            $this->db->insert('categories', [
                'user_id' => $userId,
                'name' => $category['name'],
                'type' => $category['type'],
                'icon' => $category['icon'],
                'color' => $category['color']
            ]);
        }
    }

    public function getUser() {
        return $this->user;
    }

    public function isAuthenticated() {
        return $this->user !== null;
    }

    public function getUserById($id) {
        return $this->db->fetchOne("SELECT * FROM users WHERE id = ?", [$id], "i");
    }

    public function getUserByTelegramId($telegramId) {
        return $this->db->fetchOne("SELECT * FROM users WHERE telegram_id = ?", [$telegramId], "i");
    }
}

$auth = new Auth($db);
?>