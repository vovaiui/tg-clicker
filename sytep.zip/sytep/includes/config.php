<?php
// Настройки базы данных
define('DB_HOST', 'localhost');
define('DB_USER', 'wallet112');
define('DB_PASS', 'Walletmonster');
define('DB_NAME', 'telegram_wallet');

// Настройки Telegram
define('BOT_TOKEN', '8009994182:AAG8UbkzGDX-yTF_bUkoyEzEZDdBCW8twDE');

// Настройки приложения
define('APP_URL', 'https://yourdomain.com/wallet-telegram-app');
define('CURRENCY', '₽');
define('DEFAULT_LANGUAGE', 'ru');

// Включить отладку (false в продакшене)
define('DEBUG_MODE', true);

// Автозагрузка классов
spl_autoload_register(function ($class_name) {
    include __DIR__ . '/../classes/' . $class_name . '.php';
});

// Обработка ошибок
if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Установка часового пояса
date_default_timezone_set('Europe/Moscow');

// Запуск сессии
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>