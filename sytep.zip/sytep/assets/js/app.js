// Инициализация Telegram Web App
const tg = window.Telegram.WebApp;
tg.expand();

// Глобальные переменные
let user = null;
let categories = [];
let transactions = [];

// Инициализация приложения
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Получаем данные пользователя
        const initData = tg.initData || '';
        const response = await fetch('api.php?action=init', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ initData })
        });
        
        const data = await response.json();
        
        if (data.ok) {
            user = data.user;
            loadData();
            setupEventListeners();
        } else {
            showError(data.error || 'Failed to initialize');
        }
    } catch (error) {
        showError(error.message);
    }
});

// Загрузка данных
async function loadData() {
    try {
        // Показываем индикатор загрузки
        tg.showPopup({ title: 'Загрузка...', message: 'Пожалуйста, подождите' }, () => {});
        
        // Загружаем баланс
        const balanceResponse = await fetch('api.php?action=get_balance');
        const balanceData = await balanceResponse.json();
        
        if (balanceData.ok) {
            updateBalance(balanceData);
        }
        
        // Загружаем категории
        const categoriesResponse = await fetch('api.php?action=get_categories');
        const categoriesData = await categoriesResponse.response.json();
        
        if (categoriesData.ok) {
            categories = categoriesData.categories;
        }
        
        // Загружаем транзакции
        const transactionsResponse = await fetch('api.php?action=get_transactions&limit=10');
        const transactionsData = await transactionsResponse.json();
        
        if (transactionsData.ok) {
            transactions = transactionsData.transactions;
            renderTransactions(transactions);
        }
        
        // Скрываем индикатор загрузки
        tg.closePopup();
    } catch (error) {
        showError(error.message);
    }
}

// Обновление баланса
function updateBalance(data) {
    document.getElementById('balance-amount').textContent = `${data.balance} ${CURRENCY}`;
    document.getElementById('income-amount').textContent = `${data.income} ${CURRENCY}`;
    document.getElementById('expense-amount').textContent = `${data.expense} ${CURRENCY}`;
}

// Отображение транзакций
function renderTransactions(transactions) {
    const container = document.getElementById('transactions-list');
    container.innerHTML = '';
    
    if (transactions.length === 0) {
        container.innerHTML = '<div class="empty-state">Нет транзакций</div>';
        return;
    }
    
    transactions.forEach(transaction => {
        const category = categories.find(c => c.id === transaction.category_id);
        const isIncome = category && category.type === 'income';
        
        const item = document.createElement('div');
        item.className = 'transaction-item';
        item.innerHTML = `
            <div class="transaction-info">
                <div class="transaction-category">${category ? category.name : 'Неизвестно'}</div>
                ${transaction.description ? `<div class="transaction-description">${transaction.description}</div>` : ''}
                <div class="transaction-date">${formatDate(transaction.transaction_date)}</div>
            </div>
            <div class="transaction-amount ${isIncome ? 'income' : 'expense'}">
                ${isIncome ? '+' : '-'}${transaction.amount} ${CURRENCY}
            </div>
        `;
        
        container.appendChild(item);
    });
}

// Настройка обработчиков событий
function setupEventListeners() {
    // Кнопка обновления
    document.getElementById('refresh-btn').addEventListener('click', loadData);
    
    // Кнопка добавления дохода
    document.getElementById('add-income-btn').addEventListener('click', () => showTransactionForm('income'));
    
    // Кнопка добавления расхода
    document.getElementById('add-expense-btn').addEventListener('click', () => showTransactionForm('expense'));
    
    // Кнопка статистики
    document.getElementById('stats-btn').addEventListener('click', showStats);
    
    // Кнопка целей
    document.getElementById('goals-btn').addEventListener('click', showGoals);
    
    // Кнопка категорий
    document.getElementById('categories-btn').addEventListener('click', showCategories);
    
    // Просмотр всех транзакций
    document.getElementById('view-all-transactions').addEventListener('click', (e) => {
        e.preventDefault();
        showAllTransactions();
    });
}

// Показать форму добавления транзакции
async function showTransactionForm(type) {
    try {
        // Получаем категории для выбранного типа
        const response = await fetch(`api.php?action=get_categories&type=${type}`);
        const data = await response.json();
        
        if (!data.ok) {
            throw new Error('Failed to load categories');
        }
        
        const formHtml = `
            <div class="form-group">
                <label for="amount">Сумма</label>
                <input type="number" id="amount" placeholder="0.00" step="0.01" min="0">
            </div>
            <div class="form-group">
                <label for="category">Категория</label>
                <select id="category">
                    ${data.categories.map(c => `<option value="${c.id}">${c.icon} ${c.name}</option>`).join('')}
                </select>
            </div>
            <div class="form-group">
                <label for="description">Описание (необязательно)</label>
                <input type="text" id="description" placeholder="Комментарий">
            </div>
            <div class="form-group">
                <label for="date">Дата</label>
                <input type="datetime-local" id="date" value="${new Date().toISOString().slice(0, 16)}">
            </div>
        `;
        
        tg.showPopup({
            title: type === 'income' ? 'Добавить доход' : 'Добавить расход',
            message: formHtml,
            buttons: [
                { id: 'cancel', type: 'cancel' },
                { id: 'submit', type: 'default', text: 'Добавить' }
            ]
        }, async (buttonId) => {
            if (buttonId === 'submit') {
                const amount = parseFloat(document.getElementById('amount').value);
                const categoryId = parseInt(document.getElementById('category').value);
                const description = document.getElementById('description').value;
                const date = document.getElementById('date').value;
                
                if (!amount || amount <= 0) {
                    showError('Введите корректную сумму');
                    return;
                }
                
                if (!categoryId) {
                    showError('Выберите категорию');
                    return;
                }
                
                try {
                    const response = await fetch('api.php?action=add_transaction', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            amount,
                            category_id: categoryId,
                            description,
                            transaction_date: date
                        })
                    });
                    
                    const result = await response.json();
                    
                    if (result.ok) {
                        tg.showAlert('Транзакция добавлена');
                        loadData(); // Обновляем данные
                    } else {
                        showError(result.error || 'Ошибка при добавлении транзакции');
                    }
                } catch (error) {
                    showError(error.message);
                }
            }
        });
    } catch (error) {
        showError(error.message);
    }
}

// Показать статистику
async function showStats() {
    try {
        // Получаем статистику за последние 30 дней
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(endDate.getDate() - 30);
        
        const response = await fetch('api.php?action=get_stats', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                start_date: startDate.toISOString().split('T')[0],
                end_date: endDate.toISOString().split('T')[0]
            })
        });
        
        const data = await response.json();
        
        if (!data.ok) {
            throw new Error('Failed to load stats');
        }
        
        // Формируем HTML для статистики
        let statsHtml = '<h3>Статистика за 30 дней</h3>';
        
        // Расходы по категориям
        if (data.expense_stats.length > 0) {
            statsHtml += '<h4>Расходы по категориям</h4>';
            data.expense_stats.forEach(cat => {
                statsHtml += `<div>${cat.icon} ${cat.name}: ${cat.total} ${CURRENCY}</div>`;
            });
        }
        
        // Доходы по категориям
        if (data.income_stats.length > 0) {
            statsHtml += '<h4>Доходы по категориям</h4>';
            data.income_stats.forEach(cat => {
                statsHtml += `<div>${cat.icon} ${cat.name}: ${cat.total} ${CURRENCY}</div>`;
            });
        }
        
        // Ежемесячная статистика
        if (data.monthly_stats.length > 0) {
            statsHtml += '<h4>Ежемесячная статистика</h4>';
            data.monthly_stats.forEach(month => {
                statsHtml += `<div>${month.month}: Доходы ${month.income} ${CURRENCY}, Расходы ${month.expense} ${CURRENCY}</div>`;
            });
        }
        
        tg.showPopup({
            title: 'Статистика',
            message: statsHtml,
            buttons: [
                { id: 'close', type: 'default', text: 'Закрыть' }
            ]
        }, () => {});
    } catch (error) {
        showError(error.message);
    }
}

// Показать цели
async function showGoals() {
    try {
        const response = await fetch('api.php?action=get_goals');
        const data = await response.json();
        
        if (!data.ok) {
            throw new Error('Failed to load goals');
        }
        
        let goalsHtml = '<h3>Ваши цели</h3>';
        
        if (data.goals.length === 0) {
            goalsHtml += '<div>У вас пока нет целей</div>';
        } else {
            data.goals.forEach(goal => {
                const progress = (goal.current_amount / goal.target_amount) * 100;
                goalsHtml += `
                    <div class="goal-item">
                        <h4>${goal.name}</h4>
                        <div>${goal.current_amount} / ${goal.target_amount} ${CURRENCY}</div>
                        <div class="progress-bar">
                            <div class="progress" style="width: ${progress}%"></div>
                        </div>
                        ${goal.target_date ? `<div>Цель до: ${formatDate(goal.target_date)}</div>` : ''}
                    </div>
                `;
            });
        }
        
        goalsHtml += `
            <button id="add-goal-btn" style="margin-top: 16px; width: 100%; padding: 8px; background: var(--primary-color); color: white; border: none; border-radius: 8px;">
                Добавить цель
            </button>
        `;
        
        tg.showPopup({
            title: 'Финансовые цели',
            message: goalsHtml,
            buttons: [
                { id: 'close', type: 'default', text: 'Закрыть' }
            ]
        }, (buttonId) => {
            if (buttonId === 'add-goal-btn') {
                showAddGoalForm();
            }
        });
    } catch (error) {
        showError(error.message);
    }
}

// Показать форму добавления цели
async function showAddGoalForm() {
    const formHtml = `
        <div class="form-group">
            <label for="goal-name">Название цели</label>
            <input type="text" id="goal-name" placeholder="Например: Новый телефон">
        </div>
        <div class="form-group">
            <label for="target-amount">Целевая сумма</label>
            <input type="number" id="target-amount" placeholder="0.00" step="0.01" min="0">
        </div>
        <div class="form-group">
            <label for="current-amount">Текущая сумма (необязательно)</label>
            <input type="number" id="current-amount" placeholder="0.00" step="0.01" min="0">
        </div>
        <div class="form-group">
            <label for="target-date">Целевая дата (необязательно)</label>
            <input type="date" id="target-date">
        </div>
    `;
    
    tg.showPopup({
        title: 'Добавить цель',
        message: formHtml,
        buttons: [
            { id: 'cancel', type: 'cancel' },
            { id: 'submit', type: 'default', text: 'Добавить' }
        ]
    }, async (buttonId) => {
        if (buttonId === 'submit') {
            const name = document.getElementById('goal-name').value;
            const targetAmount = parseFloat(document.getElementById('target-amount').value);
            const currentAmount = parseFloat(document.getElementById('current-amount').value) || 0;
            const targetDate = document.getElementById('target-date').value;
            
            if (!name || !targetAmount || targetAmount <= 0) {
                showError('Заполните обязательные поля');
                return;
            }
            
            try {
                const response = await fetch('api.php?action=add_goal', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        name,
                        target_amount: targetAmount,
                        current_amount: currentAmount,
                        target_date: targetDate || null
                    })
                });
                
                const result = await response.json();
                
                if (result.ok) {
                    tg.showAlert('Цель добавлена');
                    showGoals(); // Обновляем список целей
                } else {
                    showError(result.error || 'Ошибка при добавлении цели');
                }
            } catch (error) {
                showError(error.message);
            }
        }
    });
}

// Показать категории
async function showCategories() {
    try {
        const response = await fetch('api.php?action=get_categories');
        const data = await response.json();
        
        if (!data.ok) {
            throw new Error('Failed to load categories');
        }
        
        let categoriesHtml = '<h3>Ваши категории</h3>';
        
        if (data.categories.length === 0) {
            categoriesHtml += '<div>У вас пока нет категорий</div>';
        } else {
            // Разделяем категории на доходы и расходы
            const incomeCategories = data.categories.filter(c => c.type === 'income');
            const expenseCategories = data.categories.filter(c => c.type === 'expense');
            
            if (incomeCategories.length > 0) {
                categoriesHtml += '<h4>Доходы</h4>';
                incomeCategories.forEach(cat => {
                    categoriesHtml += `<div>${cat.icon} ${cat.name}</div>`;
                });
            }
            
            if (expenseCategories.length > 0) {
                categoriesHtml += '<h4>Расходы</h4>';
                expenseCategories.forEach(cat => {
                    categoriesHtml += `<div>${cat.icon} ${cat.name}</div>`;
                });
            }
        }
        
        categoriesHtml += `
            <button id="add-category-btn" style="margin-top: 16px; width: 100%; padding: 8px; background: var(--primary-color); color: white; border: none; border-radius: 8px;">
                Добавить категорию
            </button>
        `;
        
        tg.showPopup({
            title: 'Категории',
            message: categoriesHtml,
            buttons: [
                { id: 'close', type: 'default', text: 'Закрыть' }
            ]
        }, (buttonId) => {
            if (buttonId === 'add-category-btn') {
                showAddCategoryForm();
            }
        });
    } catch (error) {
        showError(error.message);
    }
}

// Показать форму добавления категории
async function showAddCategoryForm() {
    const formHtml = `
        <div class="form-group">
            <label for="category-name">Название категории</label>
            <input type="text" id="category-name" placeholder="Например: Продукты">
        </div>
        <div class="form-group">
            <label for="category-type">Тип</label>
            <select id="category-type">
                <option value="income">Доход</option>
                <option value="expense">Расход</option>
            </select>
        </div>
        <div class="form-group">
            <label for="category-icon">Иконка (необязательно)</label>
            <input type="text" id="category-icon" placeholder="Например: 🍔">
        </div>
        <div class="form-group">
            <label for="category-color">Цвет (необязательно)</label>
            <input type="color" id="category-color" value="#607D8B">
        </div>
    `;
    
    tg.showPopup({
        title: 'Добавить категорию',
        message: formHtml,
        buttons: [
            { id: 'cancel', type: 'cancel' },
            { id: 'submit', type: 'default', text: 'Добавить' }
        ]
    }, async (buttonId) => {
        if (buttonId === 'submit') {
            const name = document.getElementById('category-name').value;
            const type = document.getElementById('category-type').value;
            const icon = document.getElementById('category-icon').value || '💰';
            const color = document.getElementById('category-color').value;
            
            if (!name || !type) {
                showError('Заполните обязательные поля');
                return;
            }
            
            try {
                const response = await fetch('api.php?action=add_category', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        name,
                        type,
                        icon,
                        color
                    })
                });
                
                const result = await response.json();
                
                if (result.ok) {
                    tg.showAlert('Категория добавлена');
                    showCategories(); // Обновляем список категорий
                } else {
                    showError(result.error || 'Ошибка при добавлении категории');
                }
            } catch (error) {
                showError(error.message);
            }
        }
    });
}

// Показать все транзакции
async function showAllTransactions() {
    try {
        const response = await fetch('api.php?action=get_transactions');
        const data = await response.json();
        
        if (!data.ok) {
            throw new Error('Failed to load transactions');
        }
        
        let transactionsHtml = '<h3>Все транзакции</h3>';
        
        if (data.transactions.length === 0) {
            transactionsHtml += '<div>Нет транзакций</div>';
        } else {
            // Группируем транзакции по дате
            const grouped = groupByDate(data.transactions);
            
            for (const date in grouped) {
                transactionsHtml += `<h4>${date}</h4>`;
                
                grouped[date].forEach(transaction => {
                    const category = categories.find(c => c.id === transaction.category_id);
                    const isIncome = category && category.type === 'income';
                    
                    transactionsHtml += `
                        <div class="transaction-item">
                            <div>
                                <div>${category ? category.icon + ' ' + category.name : 'Неизвестно'}</div>
                                ${transaction.description ? `<div>${transaction.description}</div>` : ''}
                            </div>
                            <div style="color: ${isIncome ? 'var(--income-color)' : 'var(--expense-color)'}; font-weight: bold;">
                                ${isIncome ? '+' : '-'}${transaction.amount} ${CURRENCY}
                            </div>
                        </div>
                    `;
                });
            }
        }
        
        tg.showPopup({
            title: 'Все транзакции',
            message: transactionsHtml,
            buttons: [
                { id: 'close', type: 'default', text: 'Закрыть' }
            ]
        }, () => {});
    } catch (error) {
        showError(error.message);
    }
}

// Вспомогательные функции
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function groupByDate(transactions) {
    return transactions.reduce((acc, transaction) => {
        const date = new Date(transaction.transaction_date).toLocaleDateString();
        if (!acc[date]) {
            acc[date] = [];
        }
        acc[date].push(transaction);
        return acc;
    }, {});
}

function showError(message) {
    tg.showAlert(message || 'Произошла ошибка');
}